package com.cts.mfrp.Anvay.tests;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.cts.mfrp.Anvay.base.BaseTest;
import com.cts.mfrp.Anvay.pages.LandingPage;
import com.cts.mfrp.Anvay.pages.LoginPage;
import com.cts.mfrp.Anvay.utils.ConfigReader;
import com.cts.mfrp.Anvay.utils.ExcelUtils;

public class LoginTests extends BaseTest {

	private LoginPage loginPage;
	private String baseURL;
	private LandingPage landingPage;

	@BeforeClass(alwaysRun = true)
	public void pageObjectSetup()
	{
		baseURL = ConfigReader.get("base.url");
		loginPage = new LoginPage(driver());
		landingPage = new LandingPage(driver());
	}

	@BeforeMethod(alwaysRun = true)
	public void loadPage()
	{
			driver().get(baseURL);
			landingPage.loginNavigation1();
	}

	@DataProvider(name = "validLoginData")
    public Object[][] getValidLoginData() throws IOException {
        return ExcelUtils.getTestData("LoginData.xlsx", "ValidLogin");
    }

    @DataProvider(name = "invalidLoginData")
    public Object[][] getInvalidLoginData() throws IOException {
        return ExcelUtils.getTestData("LoginData.xlsx", "InvalidLogin");
    }

    @Test(groups = {"smoke"}, priority = 1)
    public void pageLoadTest()
    {
    	boolean pageLoaded = loginPage.isPageLoaded();
    	assertTrue(pageLoaded, "login page is not loaded");
    }

	@Test(dataProvider = "validLoginData", groups = {"sanity"}, priority = 2)
	public void validLoginTest(Object[] data)
{
		String role = (String) data[1];
		String email = (String) data[2];
		String password = (String) data[3];

		String baseUrl = ConfigReader.get("base.url");
	    String expectedUrl;

	    switch (role.toLowerCase())
	    {
	        case "super admin":
	            expectedUrl = baseUrl + "dashboard/super-admin";
	            break;
	        case "institution":
	            expectedUrl = baseUrl + "dashboard/institution";
	            break;
	        case "leader":
	            expectedUrl = baseUrl + "dashboard/leader";
	            break;
	        default:
	            expectedUrl = baseUrl + "dashboard/student";
	            break;
	    }
		loginPage.login(email, password);
		loginPage.waitForPageTransition(baseUrl + "login");
		assertEquals(driver().getCurrentUrl(), expectedUrl, "Wrong dashboard for role: " + role);
	}

	@Test(dataProvider = "invalidLoginData", groups = {"sanity"}, priority = 3)
	public void invalidLoginTest(Object[] data)
	{
		String username = (String) data[1];
		String password = (String) data[2];

		String emailResult = (String) data[3];
		String passwordResult = (String) data[4];
		String loginResult = (String) data[5];


		SoftAssert soft = new SoftAssert();


		if(!emailResult.equals("") || !passwordResult.equals(""))
		{
			loginPage.enterEmail(username);
			loginPage.enterPassword(password);

			if(!emailResult.equals(""))
			{
				String emailError = loginPage.emailErrorMessage();
				soft.assertEquals(emailError, emailResult);
			}
			if(!passwordResult.equals(""))
			{
				String passwordError = loginPage.passwordErrorMessage();
				soft.assertEquals(passwordError, passwordResult);
			}

			soft.assertFalse(loginPage.isSubmitButtonEnabled());
		}
		if(!loginResult.equals(""))
		{
			loginPage.login(username, password);
			String loginError = loginPage.loginErrorMessage();
			soft.assertEquals(loginError, loginResult);
		}

		soft.assertAll();
	}

	@Test(groups = {"sanity"}, priority = 4)
	public void errorMessageTest()
	{
		SoftAssert soft = new SoftAssert();

		loginPage.enterEmail("");
		soft.assertTrue(loginPage.isEmailErrorDisplayed());

		loginPage.enterPassword("");
		soft.assertTrue(loginPage.isPasswordErrorDisplayed());

		loginPage.enterEmail("example@abc");
		loginPage.enterPassword("12345678");
		soft.assertFalse(loginPage.isEmailErrorDisplayed());
		soft.assertFalse(loginPage.isPasswordErrorDisplayed());

		soft.assertAll();
	}

	@AfterMethod(alwaysRun = true)
	public void closePage()
	{
		try
		{
			JavascriptExecutor js = (JavascriptExecutor) driver();
			js.executeScript("window.localStorage.clear();");
			js.executeScript("window.sessionStorage.clear();");
			driver().manage().deleteAllCookies();
		}
		catch(Exception e)
		{
			System.out.println("no session to clear");
		}
	}
}