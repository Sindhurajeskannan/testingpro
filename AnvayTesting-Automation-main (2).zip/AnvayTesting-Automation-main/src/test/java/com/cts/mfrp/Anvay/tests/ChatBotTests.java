package com.cts.mfrp.Anvay.tests;

import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.cts.mfrp.Anvay.base.BaseTest;
import com.cts.mfrp.Anvay.pages.ChatbotPage;
import com.cts.mfrp.Anvay.pages.LandingPage;
import com.cts.mfrp.Anvay.pages.LoginPage;
import com.cts.mfrp.Anvay.utils.ConfigReader;
import com.cts.mfrp.Anvay.utils.ExcelUtils;

public class ChatBotTests extends BaseTest {

	private LandingPage landingPage;
    private LoginPage loginPage;
    private ChatbotPage chatbotPage;
    private String baseURL;

    @BeforeClass(alwaysRun = true)
    public void pageSetup()
    {
        baseURL = ConfigReader.get("base.url");
        landingPage = new LandingPage(driver());
        loginPage = new LoginPage(driver());
        chatbotPage  = new ChatbotPage(driver());

        driver().get(baseURL);
        landingPage.loginNavigation1();
        loginPage.login(ConfigReader.get("student.username"), ConfigReader.get("student.password"));

    }

    @DataProvider(name = "quickSelectData")
    public Object[][] getQuickSelectData() throws IOException
    {
       return ExcelUtils.getTestData("ChatbotData.xlsx", "QuickSelectResponses");
    }

    @DataProvider(name = "freeTextEnterKeyData")
    public Object[][] getFreeTextEnterKeyData() throws IOException
    {
        return ExcelUtils.getTestData("ChatbotData.xlsx", "FreeTextEnterKey");
    }

    @DataProvider(name = "outOfScopeData")
    public Object[][] getOutOfScopeData() throws IOException
    {
       return ExcelUtils.getTestData("ChatbotData.xlsx", "OutOfScopeQueries");
    }


    @Test(dataProvider = "quickSelectData", groups = {"sanity"}, priority = 1)
    public void quickSelectResponsesTest(Object[] data)
    {
        String buttonName = (String) data[1];

        chatbotPage.clickFloatingButton();

        switch (buttonName)
        {
            case "Register for Event":
                chatbotPage.clickQuickSelectRegisterEvent();
                break;
            case "Apply for Leader":
                chatbotPage.clickQuickSelectApplyLeader();
                break;
            case "Event Rules":
                chatbotPage.clickQuickSelectEventRules();
                break;
            case "Join a Club":
                chatbotPage.clickQuickSelectJoinClub();
                break;
            case "Points and Ranking":
                chatbotPage.clickQuickSelectPointsRanking();
                break;
            case "Create an Event":
                chatbotPage.clickQuickSelectCreateEvent();
                break;
        }

		assertTrue(chatbotPage.isLastBotMessageDisplayed(), "No bot response for quick select: " + buttonName);
		assertFalse(chatbotPage.getLastBotMessageText().isEmpty(), "Empty bot response for quick select: " + buttonName);
    }


    @Test(dataProvider = "freeTextEnterKeyData", groups = {"sanity"}, priority = 2)
    public void freeTextInputEnterKeyTest(Object[] data)
    {
        String query = (String) data[1];

        chatbotPage.clickFloatingButton();
        chatbotPage.typeMessage(query);
        chatbotPage.sendWithEnterKey();

        assertTrue(chatbotPage.isLastBotMessageDisplayed(), "No bot response for query: " + query);
        assertFalse(chatbotPage.getLastBotMessageText().isEmpty(), "Empty bot response for query: " + query);
    }

    @Test(dataProvider = "outOfScopeData", groups = {"sanity"}, priority = 3)
    public void outOfScopeQueryTest(Object[] data)
    {
        String query = (String) data[1];

        chatbotPage.clickFloatingButton();

        chatbotPage.typeMessage(query);
        chatbotPage.clickSend();

        SoftAssert soft = new SoftAssert();
        soft.assertTrue(chatbotPage.isLastBotMessageDisplayed(), "Bot did not respond for out-of-scope query: " + query);

        String response = chatbotPage.getLastBotMessageText().toLowerCase();
        soft.assertTrue(
                response.contains("multi-tenant") || response.contains("pod 2") || response.contains("only the queries"),
                "Out of scope response not appropriate for query: " + query
        );

        soft.assertAll();
    }

    @AfterMethod(alwaysRun = true)
    public void resetChatbot()
    {
        try
        {
            if (chatbotPage.isPanelDisplayed())
            {
                chatbotPage.clickClose();
            }
        }
        catch (Exception e)
        {
            System.out.println("Panel was already closed or not found");
        }
    }

}