package com.cts.mfrp.Anvay.base;

import java.io.File;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import com.cts.mfrp.Anvay.utils.ConfigReader;

public class BaseTest {

	private static final ThreadLocal<WebDriver> driverThread = new ThreadLocal<>();

	public WebDriver driver() {
		return driverThread.get();
	}

	@BeforeSuite(alwaysRun = true)
	public synchronized void suiteSetup() {

		ConfigReader.load();
		System.out.println(ConfigReader.get("base.url"));
		new File("test-outputs/reports").mkdirs();
		new File("test-outputs/screenshots").mkdirs();
	}

	@BeforeTest(alwaysRun = true)
	public void testSetup()
	{
		String browser = ConfigReader.get("browser").toLowerCase();
		WebDriver driver;
		switch(browser)
		{
		    case "chrome":
		        ChromeOptions chromeOptions = new ChromeOptions();
		        Map<String, Object> prefs = new HashMap<>();
		        prefs.put("credentials_enable_service", false);
		        prefs.put("profile.password_manager_enabled", false);
		        prefs.put("profile.password_manager_leak_detection", false);
		        prefs.put("profile.default_content_setting_values.notifications", 2);
		        chromeOptions.setExperimentalOption("prefs", prefs);
		        chromeOptions.addArguments("--disable-features=PasswordLeakDetection,PasswordManager");
		        chromeOptions.addArguments("--disable-save-password-bubble");
		        chromeOptions.addArguments("--password-store=basic");
		        chromeOptions.addArguments("--headless=new");
		        chromeOptions.addArguments("--window-size=1920,1080");
		        driver = new ChromeDriver(chromeOptions);
		        break;
		    case "edge":
		        driver = new EdgeDriver();
		        break;
		    default:
		        driver = new FirefoxDriver();
		        break;
		}

		driver.manage().window().setSize(new org.openqa.selenium.Dimension(1920, 1080));

		Duration implicitWait = Duration.ofSeconds(ConfigReader.getInt("implicit.wait"));
		driver.manage().timeouts().implicitlyWait(implicitWait);

		driverThread.set(driver);
	}

	@AfterTest(alwaysRun = true)
	public void testTeardown()
	{
		WebDriver driver = driverThread.get();
		if(driver != null)
		{
			driver.quit();
			driverThread.remove();
		}
	}

}