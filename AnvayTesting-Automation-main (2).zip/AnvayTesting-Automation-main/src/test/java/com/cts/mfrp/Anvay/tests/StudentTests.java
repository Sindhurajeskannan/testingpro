package com.cts.mfrp.Anvay.tests;

import static org.testng.Assert.assertTrue;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.cts.mfrp.Anvay.base.BaseTest;
import com.cts.mfrp.Anvay.pages.EventFeedPage;
import com.cts.mfrp.Anvay.pages.LandingPage;
import com.cts.mfrp.Anvay.pages.LoginPage;
import com.cts.mfrp.Anvay.pages.StudentDashboardPage;
import com.cts.mfrp.Anvay.utils.ConfigReader;

public class StudentTests extends BaseTest {

	private LoginPage loginPage;
	private StudentDashboardPage dashboardPage;
	private EventFeedPage eventFeedPage;
	private LandingPage landingPage;
	private String baseURL;
	private String registeredEventName;

	@BeforeClass(alwaysRun = true)
	public void pageObjectSetup()
	{
		baseURL = ConfigReader.get("base.url");
		landingPage = new LandingPage(driver());
		loginPage = new LoginPage(driver());
		dashboardPage = new StudentDashboardPage(driver());
		eventFeedPage = new EventFeedPage(driver());

		driver().get(baseURL);
		landingPage.loginNavigation1();
		loginPage.login(ConfigReader.get("student.username"), ConfigReader.get("student.password"));
	}

	@Test(groups = {"smoke"}, priority = 1)
	public void eventFeedDisplayTest()
	{
		dashboardPage.navigateToEventFeed();

		assertTrue(eventFeedPage.isPageLoaded(),
			"Event feed page should be loaded");
		assertTrue(eventFeedPage.isUpcomingSectionDisplayed(),
			"Upcoming section should be displayed");
		assertTrue(eventFeedPage.isFirstEventCardDisplayed(),
			"At least one event card should be displayed");
	}

	@Test(groups = {"sanity"}, priority = 2)
	public void registerForEventTest()
	{
		dashboardPage.navigateToEventFeed();
		registeredEventName = eventFeedPage.clickRegisterAndGetEventName();

		assertTrue(registeredEventName != null && !registeredEventName.isEmpty(),
			"Event name should be captured from the confirmation modal");
	}

	@Test(groups = {"sanity"}, priority = 3, dependsOnMethods = {"registerForEventTest"})
	public void myRegistrationsTabTest()
	{
		eventFeedPage.clickMyRegistrationsTab();

		assertTrue(eventFeedPage.isEventDisplayedInTab(registeredEventName),
			"My Registrations tab should contain the event registered: " + registeredEventName);
	}

}