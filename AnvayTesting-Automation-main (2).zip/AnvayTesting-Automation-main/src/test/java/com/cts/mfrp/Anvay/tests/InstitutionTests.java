package com.cts.mfrp.Anvay.tests;

import static org.testng.Assert.assertTrue;


import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.cts.mfrp.Anvay.base.BaseTest;
import com.cts.mfrp.Anvay.pages.CreateEventModal;
import com.cts.mfrp.Anvay.pages.EventManagementPage;
import com.cts.mfrp.Anvay.pages.InstitutionDashboardPage;
import com.cts.mfrp.Anvay.pages.LandingPage;
import com.cts.mfrp.Anvay.pages.LoginPage;
import com.cts.mfrp.Anvay.utils.ConfigReader;

public class InstitutionTests extends BaseTest {

	private InstitutionDashboardPage dashboardPage;
	private EventManagementPage eventManagementPage;
	private CreateEventModal createEventModal;

	private String baseURL;
	private LandingPage landingPage;
	private LoginPage loginPage;

	@BeforeClass(alwaysRun = true)
	public void pageObjectSetup()
	{
		baseURL = ConfigReader.get("base.url");
		landingPage = new LandingPage(driver());
		loginPage = new LoginPage(driver());
		dashboardPage = new InstitutionDashboardPage(driver());
		eventManagementPage = new EventManagementPage(driver());
		createEventModal = new CreateEventModal(driver());

		driver().get(baseURL);
		landingPage.loginNavigation1();
		loginPage.login(ConfigReader.get("institute.username"), ConfigReader.get("institute.password"));
	}


	@Test(groups = {"sanity"}, priority = 1)
	public void createEventSubmitTest()
	{
	    dashboardPage.navigateToAllEvents();
	    eventManagementPage.clickCreateEvent();
	    createEventModal.fillAndSubmit("Coding Club", "Hackathon 2026", "Technical", "9876543210", "2026-12-01T10:00", "Main Lab");
	    assertTrue(createEventModal.isModalClosed());
	    assertTrue(eventManagementPage.isFirstUpcomingRowDisplayed());
	}
}