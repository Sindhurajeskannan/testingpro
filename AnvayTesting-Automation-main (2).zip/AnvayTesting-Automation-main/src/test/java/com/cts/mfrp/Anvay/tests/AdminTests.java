package com.cts.mfrp.Anvay.tests;

import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.cts.mfrp.Anvay.base.BaseTest;
import com.cts.mfrp.Anvay.pages.AdminDashboardPage;
import com.cts.mfrp.Anvay.pages.CollegeManagementPage;
import com.cts.mfrp.Anvay.pages.LandingPage;
import com.cts.mfrp.Anvay.pages.LoginPage;
import com.cts.mfrp.Anvay.utils.ConfigReader;
import com.cts.mfrp.Anvay.utils.ExcelUtils;

public class AdminTests extends BaseTest {

	private AdminDashboardPage dashboardPage;
	private CollegeManagementPage collegeManagementPage;

	private String baseURL;
	private LandingPage landingPage;
	private LoginPage loginPage;

	@BeforeClass(alwaysRun = true)
	public void pageSetup()
	{
		baseURL = ConfigReader.get("base.url");
		landingPage = new LandingPage(driver());
		loginPage = new LoginPage(driver());
		dashboardPage = new AdminDashboardPage(driver());
		collegeManagementPage = new CollegeManagementPage(driver());
		driver().get(baseURL);
		landingPage.loginNavigation1();
		loginPage.login(ConfigReader.get("admin.username"), ConfigReader.get("admin.password"));
	}

	@DataProvider(name = "institutionSearchData")
	public Object[][] getInstitutionSearchData() throws IOException
	{
		return ExcelUtils.getTestData("AdminData.xlsx", "InstitutionSearch");
	}

	@Test(dataProvider = "institutionSearchData", groups = {"sanity"}, priority = 1)
	public void institutionSearchTest(Object[] data)
	{
		String searchTerm = (String) data[1];
		String expectedResult = (String) data[2];
		SoftAssert soft = new SoftAssert();
		dashboardPage.navigateToCollegeManagement();
		soft.assertTrue(collegeManagementPage.isSearchLoaded());
		collegeManagementPage.searchFor(searchTerm);
		if (expectedResult.equals("found"))
		{
			soft.assertFalse(collegeManagementPage.isNoResultsMsgDisplayed());
		}
		else
		{
			soft.assertTrue(collegeManagementPage.isNoResultsMsgDisplayed());
		}
		soft.assertAll();
	}

	@Test(groups = {"sanity"}, priority = 2)
	public void approveInstitutionTest()
	{

		dashboardPage.navigateToCollegeManagement();
		collegeManagementPage.resetSearch();
		collegeManagementPage.clickFirstPendingApprove();
		SoftAssert soft = new SoftAssert();
		soft.assertTrue(collegeManagementPage.isApproveModalDisplayed());
		soft.assertFalse(collegeManagementPage.isApproveCheckboxSelected());
		soft.assertFalse(collegeManagementPage.isApproveButtonEnabled());

		collegeManagementPage.clickApproveCheckbox();
		soft.assertTrue(collegeManagementPage.isApproveButtonEnabled());

		collegeManagementPage.clickApproveInstitutionButton();
		soft.assertTrue(collegeManagementPage.isSuccessBannerDisplayed());
		soft.assertTrue(collegeManagementPage.isAnyRowApproved());
		soft.assertTrue(collegeManagementPage.isDeactivatePresentForActiveRow());
		soft.assertTrue(collegeManagementPage.isStatusPresent("active"));
		soft.assertAll();
	}

	@AfterClass(alwaysRun = true)
	public void clearSession()
	{
		try
		{
			JavascriptExecutor js = (JavascriptExecutor) driver();
			js.executeScript("window.localStorage.clear();");
			js.executeScript("window.sessionStorage.clear();");
			driver().manage().deleteAllCookies();
		}
		catch (Exception e)
		{
			System.out.println("no session to clear");
		}
	}

}